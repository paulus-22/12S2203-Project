/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Sistem_Parkir;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author ASUS
 */
public class Pay_2 extends javax.swing.JFrame {
    
    static ArrayList<Integer> slotsID = new ArrayList<Integer>();
    static ArrayList<String> slots = new ArrayList<String>();
    static ArrayList<String> slotsName = new ArrayList<String>();
    
    static Connection con;
    static Statement stmt;
    static ResultSet rs;
    
    String plate = "Plate : ";
    String slot = "Slot : "; 
    String price = "Price : ";
    int price_;
    int slips, _time;
    
    static final String driver = "com.mysql.jdbc.Driver";
    static final String db = "jdbc:mysql://localhost/database_1";
    static final String user = "root";
    static final String pass = "12345";

    /**
     * Creates new form Pay_2
     */
    public Pay_2() {
        initComponents();
        Dimension layar = Toolkit.getDefaultToolkit().getScreenSize();

        int x = layar.width / 2  - this.getSize().width / 2;
        int y = layar.height / 2 - this.getSize().height / 2;

        this.setLocation(x, y);
        checks();
    }
    
    public void check(){
        String slip = jSlipNo.getText();
        slips = Integer.valueOf(slip);
        try{
            Class.forName(driver);
            
            con = DriverManager.getConnection(db, user, pass);
            stmt = con.createStatement();
            String sql = "SELECT * FROM transaction";
            rs = stmt.executeQuery(sql);
            
            while(rs.next()){
                if(rs.getInt("Slip_No")==slips){
                    jPlate.setText(plate + rs.getString("Plate"));
                    jSlot.setText(slot + rs.getString("Slot"));
                    jLabelSlip.setText("Slip Valid");
                    break;
                }
                else{
                    jPlate.setText(plate);
                    jSlot.setText(slot);
                    jLabelSlip.setText("Slip Invalid");
                }
            }
        }catch(Exception e){
            
        }
    }
    
    public void count(){
        String time = jTime.getText();
        _time = Integer.valueOf(time);
        price_ = (_time-1) * 20000;
        if (_time<2){
            jPrice.setText(price + "Free");
        }
        else if (_time >1){
            jPrice.setText(price + "Rp." + price_);
        }
    }
    
    public void pay(){
        String money = jMoney.getText();
        int _money = Integer.valueOf(money);
        if(_money < price_){
            jLabelMoney.setText("Lack of Money");
        }
        else{
            int change = _money - price_;
            try{
            Class.forName(driver);
            
            con = DriverManager.getConnection(db, user, pass);
            stmt = con.createStatement();
            String sql = "SELECT * FROM transaction";
            rs = stmt.executeQuery(sql);
            
            
            while(rs.next()){
                if(rs.getInt("Slip_No")==slips){
                    String _plate = rs.getString("Plate");
                    String _slot = rs.getString("Slot");
                    int slip_no = rs.getInt("Slip_No");
                    JOptionPane.showMessageDialog(null, "Pay Success\nPlate = " + _plate + "\nSlot = " + _slot + "\nSlip No. = " + slip_no + 
                            "\nPrice = Rp." + price_ + "\nChange = Rp." + change + "\nThank you.");
                    String update = "UPDATE transaction SET `Park_Time` = '" + _time+ "' , Payment_Status = '1', Price = '" + price_ + "' WHERE `Slip_No` = '"+ slip_no+ "'";
                    stmt.execute(update);
                    int index = slotsName.indexOf(_slot);
                    int updateindex = slotsID.get(index);
                    slotsID.set(index, 1);
                    slots.set(index, "Available");
                    break;
                }
                else{
                
            }
            stmt.close();
            con.close();
            }
            
            
        }catch(Exception e){
            
        }
        }
    }
    
    public static void checks(){
        try{
            Class.forName(driver);
            con = DriverManager.getConnection(db, user, pass);
            stmt = con.createStatement();
            String sql = "SELECT * FROM slot_parkir";
            rs = stmt.executeQuery(sql);
            
            while(rs.next()){
                slotsID.add(rs.getInt("Status_ID"));
                slots.add(rs.getString("Status"));
                slotsName.add(rs.getString("Slot"));
            }
            for(int i =0; i< slots.size(); i++){
                System.out.println(i+1);
                System.out.println(slotsName.get(i));
                System.out.println(slots.get(i));
                System.out.println(slotsID.get(i));
                System.out.println("");
            }
            
            stmt.close();
            con.close();
        } catch (Exception e){
            e.printStackTrace();
        }
    }
    
    public static void update_(){
        try{
            Class.forName(driver);
            con = DriverManager.getConnection(db, user, pass);
            stmt = con.createStatement();
            String sql = "SELECT * FROM slot_parkir";
            rs = stmt.executeQuery(sql);
            int i = 0;
            int a;
            String b, c;
            for(i=0;i<24;i++){
                a = slotsID.get(i);
                b = slots.get(i);
                c = slotsName.get(i);
                String updates = "UPDATE slot_parkir SET Status_ID = '" + a +"' , Status = '"+ b +"' WHERE Slot = '"+ c +"'";
                stmt.execute(updates);
            }
            
            stmt.close();
            con.close();
        } catch (Exception e){
            e.printStackTrace();
        }    
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jPlate = new javax.swing.JLabel();
        jSlot = new javax.swing.JLabel();
        jPrice = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jMoney = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jSlipNo = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jTime = new javax.swing.JTextField();
        jButton3 = new javax.swing.JButton();
        jLabelSlip = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jLabel1.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jLabel1.setText("Slip No        :");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(10, 60, 140, 18);

        jPlate.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jPlate.setText("Plate :");
        getContentPane().add(jPlate);
        jPlate.setBounds(10, 100, 70, 24);

        jSlot.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jSlot.setText("Slot :");
        getContentPane().add(jSlot);
        jSlot.setBounds(205, 98, 35, 19);

        jPrice.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jPrice.setText("Price :");
        getContentPane().add(jPrice);
        jPrice.setBounds(10, 200, 80, 24);

        jLabel5.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        jLabel5.setText("Insert Money Amount ");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(10, 240, 180, 21);

        jMoney.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMoneyActionPerformed(evt);
            }
        });
        getContentPane().add(jMoney);
        jMoney.setBounds(183, 237, 112, 26);

        jButton1.setBackground(new java.awt.Color(255, 255, 204));
        jButton1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton1.setForeground(new java.awt.Color(0, 153, 0));
        jButton1.setText("Pay");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(309, 281, 91, 31);
        getContentPane().add(jSlipNo);
        jSlipNo.setBounds(130, 60, 189, 26);

        jButton2.setBackground(new java.awt.Color(255, 255, 204));
        jButton2.setText("Check");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2);
        jButton2.setBounds(330, 60, 82, 29);

        jLabel7.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jLabel7.setText("Insert Time : ");
        getContentPane().add(jLabel7);
        jLabel7.setBounds(10, 130, 116, 24);

        jTime.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTimeActionPerformed(evt);
            }
        });
        getContentPane().add(jTime);
        jTime.setBounds(130, 130, 189, 26);

        jButton3.setBackground(new java.awt.Color(255, 255, 204));
        jButton3.setText("Count");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3);
        jButton3.setBounds(330, 130, 82, 29);

        jLabelSlip.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        getContentPane().add(jLabelSlip);
        jLabelSlip.setBounds(323, 50, 0, 0);

        jButton4.setBackground(new java.awt.Color(255, 255, 204));
        jButton4.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton4.setForeground(new java.awt.Color(255, 0, 0));
        jButton4.setText("Back");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton4);
        jButton4.setBounds(193, 281, 98, 31);
        getContentPane().add(jSeparator1);
        jSeparator1.setBounds(15, 183, 385, 10);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel2.setText("Pay Check");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(130, 0, 230, 48);

        jLabel4.setIcon(new javax.swing.ImageIcon("E:\\Materi Kuliah\\Semester 4\\PBO\\Week 16\\sistem parkir\\background\\Pay_2.jfif")); // NOI18N
        getContentPane().add(jLabel4);
        jLabel4.setBounds(1, 0, 420, 330);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jMoneyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMoneyActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_jMoneyActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        check();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        count();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
                pay();
                update_();
                this.setVisible(false);
        Menu a = new Menu();
        a.setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        this.setVisible(false);
        Menu a = new Menu();
        a.setVisible(true);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jTimeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTimeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTimeActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Pay_2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Pay_2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Pay_2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Pay_2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Pay_2().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabelSlip;
    private javax.swing.JTextField jMoney;
    private javax.swing.JLabel jPlate;
    private javax.swing.JLabel jPrice;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTextField jSlipNo;
    private javax.swing.JLabel jSlot;
    private javax.swing.JTextField jTime;
    // End of variables declaration//GEN-END:variables
}
