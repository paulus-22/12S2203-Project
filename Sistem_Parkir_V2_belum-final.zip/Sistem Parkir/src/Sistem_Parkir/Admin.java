/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Sistem_Parkir;

/**
 *
 * @author ASUS
 */
public class Admin {
    private String name;
    private String status;
    
    
    public String getSpot(){
        return "0";
    }
}
