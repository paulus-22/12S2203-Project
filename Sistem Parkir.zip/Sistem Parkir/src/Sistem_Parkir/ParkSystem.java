/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Sistem_Parkir;
import java.util.ArrayList;
/**
 *
 * @author ASUS
 */
public class ParkSystem {
    
ArrayList<ParkingSlot> SlotParkir = new ArrayList<ParkingSlot>();

public void resetData(){
    for(int i=1;i<7;i++){
        SlotParkir.add(new ParkingSlot("A"+String.valueOf(i),1));
    }
    for(int i=0;i<6;i++){
        SlotParkir.add(new ParkingSlot("B"+String.valueOf(i),1));
    }
    for(int i=0;i<6;i++){
        SlotParkir.add(new ParkingSlot("C"+String.valueOf(i),1));
    }
    for(int i=0;i<6;i++){
        SlotParkir.add(new ParkingSlot("D"+String.valueOf(i),1));
    }
}
    
    private String places;
    private int time;
    
    public int getTime(){
        return time;
    }
    
    public void showSpot(){
        SlotParkir.forEach(ParkingSlot ->{
        System.out.println("Slot no : " + ParkingSlot.getSlotNo() + ", Status : " + ParkingSlot.getStatus());
    });
    
    }
    
    public void menu(){
        System.out.println("Menu :");
        System.out.println("1. Show Spot");
        System.out.println("2. Park");
        System.out.println("3. Pay");
        System.out.println("4. Reset Data");
        System.out.println("5. Exit");
    }
}

