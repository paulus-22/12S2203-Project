/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Sistem_Parkir;

/**
 *
 * @author ASUS
 */
public class Cashier {
    private String employeeID;
    private String name;
    
    public int pay(){
        return 0;
    }
}
